package formation.sopra.exerciceBootSecurite.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
//@DiscriminatorValue("administrateur")
public class Administrateur extends Compte {

}
