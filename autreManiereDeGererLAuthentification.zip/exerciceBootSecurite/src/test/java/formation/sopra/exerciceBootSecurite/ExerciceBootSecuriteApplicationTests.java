package formation.sopra.exerciceBootSecurite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciceBootSecuriteApplicationTests {

	@Test
	void contextLoads() {
	}

}
