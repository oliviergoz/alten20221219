package eshop.dao;

import eshop.entity.Achat;
import eshop.entity.AchatKey;

public interface DaoAchat extends DaoGeneric<Achat, AchatKey>{

}
