package eshop.dao;

import eshop.entity.Client;

public interface DaoClient extends DaoGeneric<Client, Long>{

}
