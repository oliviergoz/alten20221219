package eshop.dao;

import eshop.entity.Commande;

public interface DaoCommande extends DaoGeneric<Commande, Long>{

}
